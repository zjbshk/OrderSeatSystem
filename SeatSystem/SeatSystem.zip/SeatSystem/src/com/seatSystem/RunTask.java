package com.seatSystem;

import com.seatSystem.bean.Task;
import com.seatSystem.bean.UserSeat;
import com.seatSystem.util.Log;
import top.itreatment.net.bean.*;
import top.itreatment.net.core.impl.ChooseSeatClientImpl;
import top.itreatment.net.res.Resource;
import top.itreatment.net.util.SeatUtil;
import top.itreatment.net.util.Util;

import java.util.ArrayList;
import java.util.List;

public class RunTask implements Runnable {

    private Task task;
    private List<SeatBean> recommendSeat = new ArrayList<>();

    public RunTask(Task task) {
        this.task = task;
    }

    @Override
    public void run() {
        ChooseSeatClientImpl chooseSeatClient = new ChooseSeatClientImpl();
        List<UserSeat> userSeats = task.getUserSeats();
        for (int i = 0; i < userSeats.size(); i++) {
            UserSeat userSeat = userSeats.get(i);
            CommonBean<String> tempCommon = null;
            CommonBean<UserBean> login = chooseSeatClient.login(userSeat.getUsername(), userSeat.getPassword());
            if (Resource.SUCCESS.equals(login.getStatus())) {
                CommonBean<CategoryInfoBean> categoryInfo = chooseSeatClient.getCategoryInfo(task.getArea());
                if (Resource.SUCCESS.equals(categoryInfo.getStatus())) {
                    int beginTime = categoryInfo.getData().getBeginTime();
                    long date = categoryInfo.getData().getDate();
                    long time = Util.getTime(date * 1000, beginTime, 0, 0);
                    int dealBeginTime = (int) (time / 1000);
                    int dealDuration = task.getDuration() * 60 * 60;


                    CommonBean<CategorySeatsInfoBean> categorySeats = chooseSeatClient.searchSeats(dealBeginTime, dealDuration, userSeats.size(), task.getArea());

                    if (Resource.SUCCESS.equals(categorySeats.getStatus())) {
                        List<SeatBean> poIs = categorySeats.getData().getPOIs();
                        List<SeatBean> seatsByTitle = SeatUtil.getSeatsByTitle(poIs, Util.toArray(userSeat.getSeats(), new String[userSeat.getSeats().size()]));
                        List<SeatBean> seatBeans = SeatUtil.filerSeats(seatsByTitle, SeatUtil.NOUSE);


                        List<SeatBean> seats = categorySeats.getData().getSeats();
                        recommendSeat.addAll(seats);
                        if (!seatBeans.isEmpty()) {
                            tempCommon = chooseSeatClient.lockSeats(dealBeginTime, dealDuration, seatBeans.get(0).getId());
                        } else {
                            if (!recommendSeat.isEmpty()) {
                                tempCommon = chooseSeatClient.lockSeats(dealBeginTime, dealDuration, seats.get(i).getId());
                            } else {
                                Log.eOut("没有位置可以选择");
                            }
                        }
                    }
                }
            }

            if (tempCommon != null && Resource.SUCCESS.equals(tempCommon.getStatus())) {
                Log.out("任务：\t" + task.getId() + "." + task.getName() + "\t用户:" + task.getUserSeats().get(i) + "选座成功");
                task.setState(Task.State.RUNNED);
            } else {
                task.setState(Task.State.ERROR);
                Log.eOut("任务：\t" + task.getId() + "." + task.getName() + "\t用户:" + task.getUserSeats().get(i) + "选座失败");
                if (tempCommon.getMsg() != null)
                    Log.eOut("原因:" + tempCommon.getMsg());
            }

            //注销和释放座位
            chooseSeatClient.unlockallseats();
            chooseSeatClient.logout();
        }
    }
}
