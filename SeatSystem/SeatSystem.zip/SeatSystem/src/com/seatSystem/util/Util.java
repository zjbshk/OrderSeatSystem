package com.seatSystem.util;

import com.beust.jcommander.ParameterException;
import com.seatSystem.bean.Task;

import java.util.Arrays;

public class Util {

    public static <T> T[] subArray(T[] ts, int start, T[] target) {
        return subArray(ts, start, ts.length, target);
    }

    public static <T> T[] subArray(T[] ts, int start, int end, T[] target) {
        if (ts == null) {
            throw new NullPointerException("ts 不可以为空");
        } else if (start <= -1 || end <= -1) {
            throw new RuntimeException("位置下标不能为负数");
        } else if (ts.length < start || end > ts.length) {
            throw new ParameterException("ts:" + Arrays.asList(ts) + "\nstart:" + start + "\nend:" + end);
        }

        int j = 0;
        for (int i = start; i < end; i++) {
            target[j++] = ts[i];
        }
        return target;
    }

}
